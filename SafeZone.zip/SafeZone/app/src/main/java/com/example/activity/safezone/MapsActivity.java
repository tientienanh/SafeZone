package com.example.activity.safezone;

import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.parse.ParseObject;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements View.OnClickListener{
    double dLatitude, dLongitude;
    private GoogleMap mMap; // Might be null if Google Play services APK is not available.
    EditText edtSearch;
    Button btnSearch, btnDone;
    public static final String ADDRESS = "address";
    public static final String DLATITUTE = "dLatitute";
    public static final String DLONGTITUTE = "dLongtitute";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        edtSearch = (EditText) findViewById(R.id.edtSearchMap);
        btnDone = (Button) findViewById(R.id.btnDone);
        InputMethodManager imm = (InputMethodManager)this.getSystemService(Service.INPUT_METHOD_SERVICE);
        imm.showSoftInput(edtSearch, 0);
        imm.hideSoftInputFromWindow(edtSearch.getWindowToken(), 0);

        btnSearch = (Button) findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(this);
        btnDone.setOnClickListener(this);

        Bundle b = getIntent().getExtras();
        String childUser = b.getString("ChildName");
        ParseQuery(childUser); // lay toa do tren Parse.com ve de load len map

    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.btnSearch) {
            onSearch();
        }
        else
            if (id == R.id.btnDone) {
                Bundle bundle = getIntent().getExtras();
//                int positionClick = bundle.getInt(RouteAdapter.ITEM_POSITION);
                Intent intentAddress = new Intent();
//                intentAddress.putExtra(RouteAdapter.ITEM_POSITION, positionClick); // send item clicked
                intentAddress.putExtra(ADDRESS, addressStr); // send address update to listView
                intentAddress.putExtra(DLATITUTE,dLatitude); // dens Latlng to update to DB
                intentAddress.putExtra(DLONGTITUTE, dLongitude);
                setResult(Activity.RESULT_OK, intentAddress);
                finish();
            }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    public void ParseQuery(String userChild){
       /* ParseQuery<ParseObject> query = ParseQuery.getQuery("Children");
        query.getFirstInBackground(new GetCallback<ParseObject>() {

            @Override
            public void done(ParseObject parseObject, com.parse.ParseException e) {
                if (e == null) {
                    dLatitude = parseObject.getDouble("lat");
                    dLongitude = parseObject.getDouble("long");

                    setUpMapIfNeeded();
                    mMap.setMyLocationEnabled(true);
                    mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                } else
                    Toast.makeText(MapsActivity.this, "Bi loi!!", Toast.LENGTH_SHORT).show();
            }
        });*/

        QueryByUser queryByUser = new QueryByUser();
        queryByUser.queryByuser("Children", "child_name", userChild, new QueryByUser.QueryByUserCallBack() {
            @Override
            public void queryByUserSuccess(ParseObject parseObject) {
                if (parseObject != null) {
                    dLatitude = parseObject.getDouble("child_latitude");
                    dLongitude = parseObject.getDouble("child_longitude");

                    setUpMapIfNeeded();
                    mMap.setMyLocationEnabled(true);
                    mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                } else
                    Toast.makeText(MapsActivity.this, "Error!", Toast.LENGTH_SHORT).show();
            }

        });


    }



    private void setUpMapIfNeeded() {
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                getCurrentLocation();
            }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_maps, menu);
        return true;
    }


    private String addressStr = ""; // ten dia chi
    void getCurrentLocation() {
        mMap.addMarker(new MarkerOptions().position(new LatLng(dLatitude, dLongitude)).title("It's Me!")).setDraggable(true);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(dLatitude, dLongitude), 16));
        mMap.getUiSettings().setZoomControlsEnabled(true);

        mMap.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
            @Override
            public void onMarkerDragStart(Marker marker) {

            }

            @Override
            public void onMarkerDrag(Marker marker) {

            }

            @Override
            public void onMarkerDragEnd(Marker marker) {
                LatLng newPosition = marker.getPosition();
                dLatitude = newPosition.latitude;
                dLongitude = newPosition.longitude;
                // lay dia chi tu Latlng
                Geocoder geo = new Geocoder(MapsActivity.this, Locale.getDefault());
                try {
                    List<Address> addresses = geo.getFromLocation(dLatitude, dLongitude, 1);
                    Address address = addresses.get(0);

                    int i = 0;
                    while (address.getAddressLine(i) != null) {
                        addressStr += address.getAddressLine(i) + ", ";
                        i++;
                    }
                    Toast.makeText(MapsActivity.this, "acdress: " + addressStr + "\n" + "lat: " + dLatitude
                            + "\n" + "long: " + dLongitude, Toast.LENGTH_LONG).show();
                    // set lai ten dia chi nay len EditText Search
                    edtSearch.setText(addressStr);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });



    }

    private void setUpMap() {
        mMap.addMarker(new MarkerOptions().position(new LatLng(0, 0)).title("Marker"));
    }

    private void onSearch(){
        String locationName = edtSearch.getText().toString();
        List<Address> addressList = null;

        Geocoder geocoder = new Geocoder(this);
        try {
            addressList = geocoder.getFromLocationName(locationName,1);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Address address = addressList.get(0);
        LatLng latLng = new LatLng(address.getLatitude(),address.getLongitude());
        dLatitude = latLng.latitude;
        dLongitude = latLng.longitude;
        setUpMapIfNeeded();
    }
}

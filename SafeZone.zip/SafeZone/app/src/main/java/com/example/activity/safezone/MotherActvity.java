package com.example.activity.safezone;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

public class MotherActvity extends AppCompatActivity implements View.OnClickListener{
Button btnLotrinh, btnMap;
    String childrenUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mother_actvity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        btnLotrinh = (Button) findViewById(R.id.btnLotrinh);
        btnMap = (Button) findViewById(R.id.btnBando);

        btnMap.setOnClickListener(this);
        btnLotrinh.setOnClickListener(this);

//        btnLotrinh.setBackgroundColor();
//        btnMap.setBackgroundColor(Color.TRANSPARENT);

        Bundle b = getIntent().getExtras();
        childrenUser = b.getString("UserChildren");  // lay tu ShowChildrenActivity
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id){
            case R.id.btnLotrinh:
                // to do something
                Intent intentRoute =  new Intent(MotherActvity.this,RouteActivity.class);
                intentRoute.putExtra("childrenName", childrenUser);
                startActivity(intentRoute);
                break;
            case R.id.btnBando:
                Intent intentMap = new Intent(MotherActvity.this,MapsActivity.class);
                intentMap.putExtra("ChildName", childrenUser);
                startActivity(intentMap);

                break;
        }

    }
}
